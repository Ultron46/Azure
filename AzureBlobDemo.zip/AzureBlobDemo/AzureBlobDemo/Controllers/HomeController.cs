﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AzureBlobDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(string id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase uploadFile)
        {
            foreach (string file in Request.Files)
            {
                uploadFile = Request.Files[file];
            }
            BlobManager BlobManagerObj = new BlobManager("trainingblobcontainer");
            string FileAbsoluteUri = BlobManagerObj.UploadFile(uploadFile);

            return RedirectToAction("Get");
        }

        public ActionResult Get()
        {
            BlobManager BlobManagerObj = new BlobManager("trainingblobcontainer");
            List<string> fileList = BlobManagerObj.BlobList();
            return View(fileList);
        }
        public ActionResult Delete(string uri)
        {
            BlobManager BlobManagerObj = new BlobManager("trainingblobcontainer");
            BlobManagerObj.DeleteBlob(uri);
            return RedirectToAction("Get");
        }
    }
}